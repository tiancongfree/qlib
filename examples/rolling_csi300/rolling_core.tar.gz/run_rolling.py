"""
Rolling Retraining for LightGBM on CSI300 (2020-2024).

Training window expands over time (ROLL_EX):
  - Initial train: 2008-2018, valid: 2019, test starts at 2020
  - Each step: test window slides forward by ~60 trading days (~3 months)
  - Training window expands to include more recent data
  - Model is retrained from scratch each step

This addresses the "model staleness" issue found in the static model,
where IC degraded from 0.036 (2020) to 0.011 (2023).
"""

import os
import sys
from pathlib import Path

# Avoid importing local qlib source (which has uncompiled C extensions)
if str(Path(__file__).parent.parent.parent) in sys.path:
    sys.path.remove(str(Path(__file__).parent.parent.parent))

from qlib import auto_init
from qlib.contrib.rolling.base import Rolling

CONF_PATH = Path(__file__).parent / "rolling_config.yaml"


def main():
    auto_init(provider_uri="~/.qlib/qlib_data/cn_data", region="cn")

    # Clean previous rolling experiments
    mlruns = Path(__file__).parent / "mlruns"
    if not mlruns.exists():
        os.makedirs(mlruns, exist_ok=True)

    rolling = Rolling(
        conf_path=CONF_PATH,
        step=60,         # ~3 months per rolling window (quarterly retraining)
        horizon=20,      # 20-day prediction horizon
        exp_name="rolling_csi300_lgbm",
    )

    print("=" * 60)
    print("  Rolling Retraining: LightGBM + Alpha158 on CSI300")
    print("=" * 60)
    print(f"  Step: 60 trading days (~quarterly)")
    print(f"  Horizon: 20 days")
    print(f"  Mode: Expanding window (ROLL_EX)")
    print("=" * 60)

    task_list = rolling.get_task_list()
    print(f"\nTotal rolling tasks to train: {len(task_list)}")
    for i, t in enumerate(task_list):
        segs = t["dataset"]["kwargs"]["segments"]
        print(f"  Task {i+1}: train {segs['train']}, valid {segs['valid']}, test {segs['test']}")

    print("\nStarting rolling training...")
    rolling.run()
    print("\nDone! Results saved in mlruns/")


if __name__ == "__main__":
    main()
